# Engineering Handbook

This handbook defines the engineering policies for the `project-design` skill repository at `Mr-RedHat-fb/project-design-skill`. It is read by the implementing agent and consulted by any human contributor.

## License

The repository is licensed under MIT. The `LICENSE` file at the repository root is authoritative; this section motivates the choice and lists implications.

**Motivation.** MIT is the operator's standing choice for skill projects. It is short, permissive, widely understood, and imposes no obligations on consumers that would conflict with the multi-skill plugin ecosystem.

**Implications.**

- Contributors retain copyright on their contributions but license them under MIT to the project.
- Downstream consumers (plugin marketplace, plugin users) may freely use, modify, and redistribute.
- No copyleft obligations. No attribution beyond what MIT requires.

**Copyright line.** The `LICENSE` file uses the form:

```
Copyright (c) 2026 Mr-RedHat-fb <mrredhat317@gmail.com>
```

The personal account is the copyright holder because it is the canonical repository. The fork at `alfred-intelligence` does not alter copyright; it is a synced mirror.

## Branch strategy

Trunk-based development with short-lived feature branches.

**`main`** — protected. Always green. Releases tagged from `main`.

**Feature branches** — named with prefix and slug: `refactor/<slug>`, `feat/<slug>`, `docs/<slug>`, `fix/<slug>`, `chore/<slug>`. Examples: `refactor/split-bootstrap`, `feat/exploration-map-v2`, `docs/update-readme`.

Feature branches are deleted after merge.

**No long-running release branches.** Hotfixes branch from `main` and merge back to `main`; the release tag is moved or a new patch tag is cut.

## Commits

**Conventional Commits.** Required on all commits to feature branches and to `main`. Format:

```
<type>(<scope>): <subject>

[optional body]

[optional footer]
```

Types in use:

| Type | When |
|------|------|
| `feat` | New skill feature or trigger |
| `fix` | Behaviour correction |
| `refactor` | Structural change, no behavioural change |
| `docs` | Documentation only |
| `chore` | Tooling, dependencies, formatting, gitignore |
| `test` | Test additions or fixes (if a test suite exists) |
| `ci` | CI configuration changes |

**Subject style.** Imperative mood, lowercase first letter, no trailing period, under 72 characters. The subject describes the *effect*, not the *implementation*.

Good: `refactor: extract operationalization policies to references`
Bad: `refactor: moved 76 lines from SKILL.md to open-questions.md`

**Body.** Optional. Use when the commit needs context the diff cannot convey — typically deviation documentation from the design package, or rationale for a non-obvious approach.

**Footer.** Used for `BREAKING CHANGE:` markers and `Closes #N` issue references.

**No mixed-purpose commits.** One Conventional Commits type per commit. If a change spans types, split it.

## Pull requests

**Title.** Mirrors the Conventional Commits subject of the primary commit. The PR's squash-merge commit on `main` uses this title.

**Description template.**

```markdown
## Summary
One paragraph: what this PR achieves.

## Linked design
Reference to the relevant design document, e.g. `project-design-design/03-short-horizon.md § M1 Steps 1-9`.

## Changes
- Bullet list of effects, not implementation details.

## Verification
How the change was verified (manual smoke test, CI status, line counts, etc.).

## Deviations from plan
Any deviations from the linked design and why.
```

**Review requirement.** One reviewer approval (the operator) before merge. Implementing agent does not self-approve.

**Merge strategy.** Squash merge. The squash commit's subject is the PR title; the body is the PR description trimmed.

**Force pushes.** Allowed on feature branches before review. Disallowed once a reviewer has commented. After review starts, use additional commits and let the squash merge collapse them.

## Releases

**Tool.** release-please configured for Conventional Commits.

**Cadence.** Release-as-needed. A release is cut when:

- A meaningful feature lands (feat-level change)
- A user-visible fix lands (fix-level change)
- An accumulated batch of refactors warrants exposing a new version to the marketplace

Pure `docs:`, `chore:`, `ci:`, and internal `refactor:` commits do not trigger a release on their own.

**Version scheme.** SemVer.

| Bump | Triggered by |
|------|--------------|
| Major | `BREAKING CHANGE:` footer or `<type>!:` subject marker |
| Minor | Any `feat:` commit since last release |
| Patch | `fix:` commits only since last release |

**Tagging.** release-please opens a release PR that, when merged, creates the git tag `v<version>` and a GitHub Release. The tag and release are authoritative.

**Marketplace sync.** Upon release, the operator runs `skill-to-plugin` (or its successor) to update `plugin.json.version` and refresh the marketplace entry. CI on the marketplace repository validates the version pointer.

## Issue and PR templates

The repository uses GitHub issue templates for bug reports and feature requests, and a PR template (described above). These templates are generated and maintained by `repo-bootstrap`, not by `project-design`. If the templates are absent or stale, run `repo-bootstrap` against the repo.

## Contributing and conduct

**`CONTRIBUTING.md`** — light. Describes how to clone, how to install pre-commit hooks (if any), how to open an issue, and how to open a PR.

**`CODE_OF_CONDUCT.md`** — Contributor Covenant short form. Public-facing requirement; not negotiable for a public repo.

**`SECURITY.md`** — light. Directs disclosure to GitHub Security advisories first, with `alfred@gegge.se` as fallback for cases where Security Advisories is not accessible.

These files are generated by `repo-bootstrap`. If missing, run that skill.

## Code style and formatting

The skill is markdown-heavy with no compiled code. Style policy:

- Markdown linted with `markdownlint` if installed (CI does not require it, soft check)
- YAML files indented two spaces
- JSON files use two-space indentation, no trailing commas
- Shell scripts (if any) shellcheck-clean

`.editorconfig` enforces these. The file is generated by `repo-bootstrap`.

## Dependencies

The skill itself has no runtime dependencies. The implementing agent and the operator's shell are the runtime.

Tooling dependencies (jq, yq, gh, git) are documented in `README.md` § Prerequisites. The skill does not bundle them; the operator installs them.

## Maintenance

**Stale issues.** Issues with no activity for 90 days receive a stale-flag comment. 30 days after that, they are closed unless re-engaged. The implementing agent does not perform this — it is operator-driven via Issue management.

**Dependabot.** Configured via `repo-bootstrap`'s `dependabot.yml`. Updates open PRs against `main`. Operator reviews and merges.

**Deprecation policy.** Skill triggers and reference filenames are part of the public contract. Deprecations are announced one minor release before removal. Document deprecations in `CHANGELOG.md` under a `Deprecated` heading.

## Out-of-band changes

Direct pushes to `main` are technically permitted (branch protection is soft in `solo+contrib` mode) but are reserved for genuine emergencies. Each direct push must be followed by a retroactive PR-style note in the next release notes explaining what bypassed review and why.
