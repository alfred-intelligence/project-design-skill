# Agent Loop

This document specifies how the implementing agent runs over time: when it reports, what to report, when to escalate, and when the loop terminates.

## Loop scope

The implementing agent's loop covers M1 (structural extraction) and M2 (bootstrap removal). M3 and M4 are not in this loop; they are owned by separate efforts (M3 has its own design package in the `repo-bootstrap-skill` repository; M4 is operator-driven plugin packaging).

## Cadence

**Per branch, per PR.** The agent reports at PR open and at PR resolution (merge or close). It does not report mid-branch unless escalating.

This cadence matches the "Per branch, PR" row in the project size calibration table for medium projects.

## Reporting format

Reports are PR descriptions and PR comments. No separate chat narration; no status logs in the repo.

### PR open report

```markdown
## M<N>: <short title>

### Linked design
project-design-design/03-short-horizon.md § M<N> Steps <range>

### Summary
One sentence describing the milestone's effect.

### Steps executed
- Step X: <effect> [commit <sha>]
- Step Y: <effect> [commit <sha>]
- ...

### Verification
- SKILL.md line count: <N>
- Reference file inventory: <list>
- Grep checks: <results>

### Deviations from plan
None | <list with reasons>

### Pending operator action
Review and merge, or request changes.
```

### PR close report (after merge)

```markdown
## M<N> closed

Squash merge commit: <sha>
Branch deleted: yes

### Smoke test
- <test 1>: <result>
- <test 2>: <result>

### Next action
Open PR for M<N+1> | Loop complete | Blocked: <reason>
```

### PR close report (after close without merge)

If a PR is closed without merging, the agent reports why and what it plans next (typically: re-open with corrections, or escalate).

## Escalation

The agent escalates by stopping work and emitting an `Operator-input-required` comment on the active PR (or, if no PR is open, on a fresh issue with the same title).

### Escalation triggers

| Trigger | Example | Action |
|---------|---------|--------|
| Must-not-assume question surfaces | License clarification, identifier disclosure | Stop. Cite `references/open-questions.md`. List options. |
| Verification rule fails for unclear reason | grep returns unexpected hits | Stop. Quote the actual output. Propose interpretations. |
| Source content differs from design package | Line numbers in 03 don't match reality | Stop. Show the actual content. Ask whether to adapt or revise 03. |
| Merge conflict not resolvable by simple rebase | History rewritten upstream | Stop. Describe conflict. Wait for guidance. |
| Step in 03 is ambiguous or contradicted by 04 | 03 says squash, 04 says rebase | Stop. Quote both. Ask which governs. |

### Non-escalation cases

The agent does not escalate for:

- Routine formatting choices within established conventions
- Sub-step ordering that does not change outcomes
- Commit message phrasing within the convention
- Choice between equally valid filenames or paths when not specified
- Recovery from transient CI failures (retry once, then escalate if it persists)

## Termination

The loop terminates when one of three conditions holds.

### Normal termination

Both M1 and M2 PRs merged, smoke test from `03 § Verification at end of M2` passes, and the agent emits a final report:

```markdown
## Loop complete

M1: merged at <sha>, smoke OK
M2: merged at <sha>, smoke OK

### Final state
- SKILL.md: <N> lines (target ≤ 400)
- references/: <count> files
- Bootstrap content: removed

### Handoff
- M3 (repo-bootstrap skill construction) is operator-driven and owned outside this repository.
- M4 (plugin packaging) is operator-driven via skill-to-plugin.

The implementing agent stops here.
```

### Operator-requested termination

The operator may close the loop at any point with a `Loop-stop` comment on the active PR. The agent immediately stops, summarizes work in progress, and exits.

### Failure termination

If the agent is blocked for more than 24 hours of operator inactivity on an escalation, it emits a status comment and stops. Resuming requires the operator to address the escalation and emit `Loop-resume` (or open a new session with fresh context).

## Re-entry

If the loop is stopped and later resumed (operator-requested or failure-recovered), the agent on re-entry:

1. Reads 00-07.
2. Runs `git log` against the target branch to identify what has already been done.
3. Identifies the next pending step from 03.
4. Reports re-entry status before continuing.

It does not silently resume; the operator must see the re-entry report.

## What the operator does in the loop

The operator's role in the loop:

| Event | Operator action |
|-------|-----------------|
| Agent opens PR | Review, request changes, or approve and merge |
| Agent escalates | Answer the question or unblock the issue |
| Agent reports completion | Verify and ratify or rollback |
| Loop stuck | Issue `Loop-stop` and investigate |

The operator does not write code in the loop. Doing so during agent execution risks state divergence. If the operator wants to intervene with code, they issue `Loop-stop` first, make changes, then explicitly hand back with a fresh design-package read.

## Concurrency

Single-threaded. Only one PR open at a time from the agent. M1 must merge before M2 opens.

If a parallel branch from the operator exists for unrelated work, the agent does not touch it. Coordination is the operator's job.

## State

The agent is stateless across sessions. It rereads 00-07 and `git log` at every session start. No persistent agent memory is required; the design package and git history together hold all the state the agent needs.

## Logging

CI logs are sufficient. The agent does not emit additional logs to the repository or to chat beyond the structured PR reports.

## Exit interview

Once the loop terminates normally, the operator may invoke the agent one final time with a `Retro` prompt asking what went well, what was hard, and what should change in 03 for next time. The agent produces a short reply (under 200 lines) and stops.

This is optional. If the operator does not ask for a retro, the loop just ends.
