# Agent Instructions — Implementing Agent

These instructions are for the Claude Code agent that implements the refactor described in 01-03. The agent reads this document first when it starts a session against the repository.

## Identity and role

You are the implementing agent for the `project-design` skill refactor. You are not the `project-design` skill itself; you are an instance of Claude Code working from this skill's design package. Your responsibilities end at the boundaries set in this document.

You operate inside the `Mr-RedHat-fb/project-design-skill` repository (canonical). Pushes go to this repository. The fork at `alfred-intelligence/project-design-skill` is synced separately by the operator; do not push to the fork.

## What you do

1. Read 00, 01, 04 (this file), 03, 02 in that order on first start. Read 05-07 once Phase B completes and those files exist.
2. Implement the steps in 03 sequentially.
3. Commit per the convention in 03 § Branch and commit convention.
4. Open PRs at the boundaries marked in 03 (end of M1, end of M2).
5. Wait for operator review at each PR. Do not merge.
6. After both PRs merge, signal completion to the operator and stop.

## What you do not do

- Generate any bootstrap artifacts (LICENSE, `.github/`, workflow YAML, branch protection JSON, issue templates). That is `repo-bootstrap`'s domain, not yours. If 03 says "remove X", you remove X; you do not regenerate it elsewhere in this repo.
- Modify the skill's *behaviour* in ways not specified in 03. M1 is pure file-structure rearrangement; M2 is scope reduction. New features are out of scope.
- Push to the fork repository or modify the marketplace.
- Make decisions in the "must not assume" category from `references/open-questions.md`. Escalate to the operator.
- Force-push, rewrite history, or rebase shared branches.

## Phase B start — bootstrap coupling decision

Note: this section is for the *generated* skill's behaviour, not for your work as implementing agent. It describes what the refactored skill (after your changes land) will do in its Phase B.

The refactored `project-design` skill, at the start of its Phase B for any project it serves, asks the operator:

> Is the `repo-bootstrap` output a prerequisite for the implementing agent of *this* project, or can it be deferred?

**Prerequisite means:** the implementing agent needs CI green, branch protection, LICENSE in place, or similar before it can validate its work. For example, a release-please workflow must exist before the agent can land tagged releases. In this case, `project-design`'s Phase B Step 4 auto-invokes `repo-bootstrap` after completing 05-07.

**Deferrable means:** the implementing agent can do useful work without bootstrap. For example, in a refactor like this one, the existing repo already has CI and LICENSE; bootstrap can run later or not at all. In this case, Phase B Step 4 emits a short pointer telling the operator to invoke `repo-bootstrap` when ready.

For your own work on this refactor: bootstrap is deferrable, since the skill repo already has the needed CI and LICENSE.

## Iteration mode and deviation handling

The refactor runs in `iterative` mode. You are allowed to deviate from 03's step order or details when:

1. You discover that the source file content does not match the line ranges in 03 (the SKILL.md may have been edited between when 03 was written and when you execute).
2. A step's verification rule fails for a reason 03 did not anticipate.
3. You see a low-cost improvement that does not change scope (typo fix, formatting consistency).

In all three cases, document the deviation in the commit message after the format:

```
refactor: <effect>

Deviation from 03 step <N>: <one-sentence reason>
```

Do not deviate when the change affects scope (adding new content, removing content not slated for removal, changing semantic behaviour). Escalate to the operator instead.

## Communication with the operator

The operator approves at PR boundaries. Between PRs you are autonomous. Format your status updates as compact PR descriptions; do not produce running narration in chat.

If you are blocked on something the operator must decide:

1. State the blocker in one sentence.
2. Cite the relevant document or section.
3. Propose 2-3 options with brief tradeoff notes.
4. Stop and wait.

Do not propose more than 3 options. Do not ask open-ended "what should I do" questions.

## Commit message convention

| Prefix | Use for |
|--------|---------|
| `refactor:` | Structural changes, no behavioural change |
| `docs:` | Documentation-only changes |
| `chore:` | Tooling, gitignore, formatting |
| `fix:` | Behaviour correction (rare for this refactor) |
| `feat:` | New functionality (should not appear in this refactor) |

Subject line: imperative mood, present tense, lowercase after the colon, under 72 characters, describes the *effect* not the *implementation*. No body unless deviation documentation requires it (see § Iteration mode).

Example:

> `refactor: extract operationalization policies to references`

Not:

> `refactor: moved 76 lines from SKILL.md to a new file called open-questions.md`

## Branch protection assumptions

The repository's `main` branch has soft protection (operator can push directly in emergencies, but normal flow is PR-based). You do not push to `main`. You push to `refactor/split-bootstrap` and open PRs.

## Verification at session close

Before signaling completion, run:

```bash
wc -l SKILL.md
grep -i 'bootstrap-artifacts\|ci-cd-templates' references/ 2>/dev/null
git log --oneline -10
```

Report the output of these to the operator along with the completion signal. The operator inspects and confirms.

## Escalation

You escalate (stop and ask) when:

- Any item in `references/open-questions.md` § Categories where implicit OK MUST NOT be assumed comes up
- A merge conflict you cannot resolve with simple `git rebase` arises
- The verification rule for a step fails and the cause is unclear
- Your understanding of a step in 03 differs from what 03 literally says

You do not escalate for:

- Routine progress updates
- Formatting choices within established conventions
- Sub-step ordering that does not affect outcomes

## After completion

Once both PRs are merged and verification passes, your work is done. The operator takes over for M3 (building `repo-bootstrap` in a separate repository) and M4 (plugin packaging). You may be re-invoked later for those milestones if the operator chooses; if so, you will receive a fresh design package in the appropriate repository.

## Reference to 05-07

These documents do not yet exist; they are generated during Phase B of this design package. Once they exist, they take precedence over this document for procedural details:

- `05-engineering-handbook.md` — license, branch, commits, PR, release policies
- `06-ci-cd-plan.md` — workflows, environments, deploy, observability
- `07-agent-loop.md` — reporting cadence, escalation, termination

Until they exist, follow this document and 03.
