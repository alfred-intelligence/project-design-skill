# Project Design Package — Index

This folder contains the design package for refactoring the `project-design` skill into a leaner, single-purpose skill that generates only design documents (00-07) and delegates operationalization artifacts to a separate `repo-bootstrap` skill.

## Reading order

| Role | Read in order |
|------|---------------|
| Operator (you) | 01 → 02 → 03 → 04 |
| Implementing agent (Claude Code) | 00 → 01 → 04 → 03 → 02 → 05 → 06 → 07 |
| Reviewer | 01 → 02 → 05 → 06 |

The implementing agent reads 04 early because that file tells the agent how to work; from there it consults 03 for steps and 05-07 for procedural rules.

## Documents

| File | Purpose | Phase | Status |
|------|---------|-------|--------|
| `00-index.md` | This file | — | — |
| `01-whitepaper.md` | What is being built, why, for whom | A | Generated |
| `02-long-horizon.md` | Milestones M1-M4 | A | Generated |
| `03-short-horizon.md` | Detailed steps for the nearest milestone | A | Generated; revision possible at Phase B start |
| `04-agent-instructions.md` | How the implementing agent works | A | Generated; revision possible at Phase B start |
| `05-engineering-handbook.md` | License, branch, commit, PR, release policies | B | Pending |
| `06-ci-cd-plan.md` | Workflows, environments, observability | B | Pending |
| `07-agent-loop.md` | Reporting, escalation, termination rules | B | Pending |

## Sibling skill

This package designs the `project-design` skill only. The `repo-bootstrap` skill is a sibling project with its own design package and its own repository. Documents in this package reference `repo-bootstrap` where the boundary is relevant but never specify its internals.

## Open questions parked at Phase A close

None. All Phase A questions resolved by the operator before generation.

## Phase B prerequisites

Before Phase B begins, the operator must:

1. Confirm the repo `Mr-RedHat-fb/project-design-skill` exists with these design documents committed.
2. Run the Phase A → Phase B confidentiality checklist (see SKILL.md for the current canonical version).
3. Decide on bootstrap-coupling mode (see 04 § Phase B start).
