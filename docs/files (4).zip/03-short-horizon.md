# Short Horizon — Detailed Plan for M1 and M2

This document covers M1 (structural extraction) and M2 (bootstrap removal) at step granularity. M3 and M4 are detailed later in their respective design packages or via Phase C revision of this document.

The implementing agent executes steps in order. Each step has a clear file effect and a verification rule. Deviations from the listed order are allowed when justified; the agent flags the deviation and motivates it in the relevant commit.

## Branch and commit convention

- Single feature branch off `main`: `refactor/split-bootstrap`
- One commit per logical group of steps (typically 1-3 steps)
- Conventional Commits format: `refactor:`, `docs:`, `chore:`
- Squash merge to `main` when M1 is fully complete, then again when M2 is complete
- No force-pushes; if rebase needed, document why

## M1 — Structural extraction

### Step 1 — Create branch and verify baseline

```bash
cd <skill-repo>
git checkout -b refactor/split-bootstrap
wc -l SKILL.md   # confirm ~494 lines as starting state
```

Verification: starting line count recorded in the branch's first commit message.

### Step 2 — Extract Open Questions Tracking

Source: SKILL.md lines 73-148 (the full section starting `## Open questions tracking` through to but not including the next `---` separator).

Target: create `references/open-questions.md` with the extracted content. Add a one-paragraph H1 introduction explaining the file's role.

Verification: line count of new file is approximately 80 lines; SKILL.md drops by approximately 76 lines.

### Step 3 — Replace extracted section in SKILL.md

Replace the removed Open Questions Tracking content with a short pointer in SKILL.md:

```markdown
## Open questions tracking

The skill maintains running open questions and audits them at milestones. Implicit OK is permitted for aesthetic and reversible decisions; explicit confirmation is required for legal, security, identity, and material downstream consequences. See `references/open-questions.md` for the full policy.
```

Verification: the pointer paragraph is 2-4 lines; no information lost in SKILL.md that an operator running the skill would need at the SKILL.md reading layer.

### Step 4 — Extract Implementation Mode subsection

Source: SKILL.md lines 214-256 (the subsection `#### Implementation mode` plus the two sub-modes `iterative` and `spec-first`).

Target: create `references/implementation-modes.md`. Keep `### Implementation mode` as the H3 in the new file's structure; H1 is the introduction.

Verification: the new file is approximately 50 lines; SKILL.md drops by approximately 42 lines.

### Step 5 — Replace extracted Implementation Mode in SKILL.md

Replace the removed content with a short pointer that retains the table row in § Explicit decisions in Phase A. The pointer should make clear that the choice between modes is an explicit Phase A decision and direct the reader to the reference for the full description.

Verification: the section "Explicit decisions in Phase A" still introduces the decision; the modes themselves are described in the reference.

### Step 6 — Extract Phase A → B Confidentiality Checklist

Source: SKILL.md lines 292-334 (the full `## Phase A → Phase B confidentiality checklist` section, including subsections).

Target: create `references/confidentiality-checklist.md`. Use H1 for the file title and H2/H3 for subsections.

Verification: the new file is approximately 45 lines; SKILL.md drops by approximately 40 lines.

### Step 7 — Replace confidentiality checklist in SKILL.md

Replace with a short pointer. SKILL.md should still contain the policy statement that the checklist runs at Phase A → B transition, but the checklist's items themselves live in the reference.

Verification: any agent reading SKILL.md alone still knows *when* the checklist must run; reading the reference is required to know *what* it asks.

### Step 8 — Sanity-check SKILL.md

```bash
wc -l SKILL.md   # target: ≤ 400 lines, ideally ~340
```

Read through SKILL.md top to bottom. Verify:

- All H2 sections still introduce their topic clearly
- All pointers to `references/*.md` resolve to files that exist
- No reference loops (file A says "see B", B says "see A" with no actual content)
- No orphaned mentions of moved content

Verification: visual review by the operator after the agent reports M1 ready for review.

### Step 9 — Commit M1

```bash
git add SKILL.md references/
git commit -m "refactor: extract operationalization policies to references"
git push origin refactor/split-bootstrap
```

Open a PR titled "Refactor — extract policies to references (M1 of 4)". Wait for operator review before proceeding to M2. The PR description references this short horizon document.

## M2 — Bootstrap removal

### Step 10 — Audit current bootstrap content

List everything that mentions bootstrap, CI templates, or workflow generation:

```bash
grep -rn -E 'bootstrap|workflow|\.github' SKILL.md references/
```

Produce a checklist of items to remove or trim. Verification: the checklist is committed as a draft note (not pushed) so the operator can review what's targeted before removal.

### Step 11 — Remove `references/bootstrap-artifacts.md`

```bash
git rm references/bootstrap-artifacts.md
```

This file's content moves to the `repo-bootstrap` repository (handled in M3). Verification: file is gone.

### Step 12 — Remove `references/ci-cd-templates.md`

```bash
git rm references/ci-cd-templates.md
```

Same migration target. Verification: file is gone.

### Step 13 — Trim `references/engineering-handbook-templates.md`

Retain only the design-level guidance — descriptions of what each section of 05-engineering-handbook should contain and what decisions it captures. Remove concrete YAML, JSON, or other committable artefact content.

Target length: down from current ~354 lines to roughly 150 lines (design-level only).

Verification: a diff review shows that all retained content is *about* the engineering handbook document itself, not about bootstrap files.

### Step 14 — Rewrite Phase B Step 3 in SKILL.md

Before:

> Step 3 — Generate 05-07 + bootstrap

After:

> Step 3 — Generate 05-07 documents only. Phase B Step 4 handles bootstrap coupling.

Verification: SKILL.md no longer describes bootstrap file generation as a `project-design` responsibility.

### Step 15 — Add Phase B Step 0 (bootstrap-coupling decision)

Insert a new Step 0 at the start of Phase B that asks the operator whether bootstrap artifacts are a prerequisite for the implementing agent.

Two outcomes:

- **Prerequisite.** `project-design` invokes `repo-bootstrap` after Step 3, before handing off to the implementer.
- **Deferrable.** `project-design` completes Step 3, instructs the operator to invoke `repo-bootstrap` separately, and hands off to the implementer immediately with a note that bootstrap is pending.

Verification: the SKILL.md text for Phase B contains a clearly marked Step 0 and the two outcome branches.

### Step 16 — Remove Bootstrap folder section

Remove the entire `### Bootstrap folder` section from SKILL.md (currently lines 368-399). Its content (the tree diagram of bootstrap/ contents and the stack-specific additions list) belongs to `repo-bootstrap`.

Verification: no `bootstrap/` tree appears in SKILL.md.

### Step 17 — Update Important Principles section

Remove the principle "Bootstrap is not design — `bootstrap/` contains importable files, not descriptions". The principle is true but no longer relevant in this skill since bootstrap is fully out of scope.

Verification: principle is gone; the surrounding list still flows.

### Step 18 — Update 00-index template

If the skill currently generates a `00-index.md` for projects that mentions bootstrap, remove that mention. The implementing agent reads `repo-bootstrap`'s output separately when relevant.

Verification: 00-index template in `references/document-templates.md` does not reference bootstrap.

### Step 19 — Update README of the skill repo

Reflect the narrower scope in the repo's `README.md`. Mention `repo-bootstrap` as the sibling skill and link to its repository. Note the canonical-fork repo arrangement so external users know where the source-of-truth lives.

Verification: README explicitly disclaims bootstrap generation and points to `repo-bootstrap`.

### Step 20 — Sanity-check SKILL.md

```bash
wc -l SKILL.md
grep -i bootstrap SKILL.md   # should be zero or only relational mentions
```

Verification: no bootstrap *generation* mentioned; bootstrap *referenced* only at the Step 0 decision point and in 04 instructions to the implementer.

### Step 21 — Commit M2

```bash
git add -A
git commit -m "refactor: remove bootstrap generation; defer to repo-bootstrap skill"
git push origin refactor/split-bootstrap
```

Open a follow-up PR titled "Refactor — bootstrap removal (M2 of 4)". Wait for operator review.

### Step 22 — Merge to main

After operator approval on both PRs, squash-merge in order: M1 first, then M2. Delete the feature branch.

Verification: `main` reflects both M1 and M2 changes; CI green; the skill repository's SKILL.md is under 400 lines and contains no bootstrap generation.

## Verification at end of M2

End-to-end smoke test:

1. From a fresh shell, invoke the refactored `project-design` against a tiny test project.
2. Confirm Phase A produces 00-04 and no bootstrap files.
3. Confirm Phase B asks the bootstrap-coupling question.
4. Confirm Phase B produces 05-07 and nothing else.
5. Manually invoke `repo-bootstrap` (or, if M3 not yet complete, document the missing handoff).

Record the test in the M2 PR description.
