# Long Horizon — Milestones

Four milestones. Each has a defined goal, scope boundary, success criteria, and exit conditions. The order is sequential: M2 depends on M1; M3 depends on `repo-bootstrap` existing externally; M4 depends on M1-M3 being green.

## M1 — Structural extraction (internal cleanup)

**Goal.** Reduce SKILL.md to under 400 lines by moving operationalization-heavy sections into `references/` files. No behavioural changes.

**Scope.** Three sections moved out of SKILL.md:

- Open Questions Tracking (currently lines 73-148, ~76 lines) → `references/open-questions.md`
- Implementation Mode subsection (currently lines 214-256, ~42 lines) → `references/implementation-modes.md`
- Phase A → Phase B Confidentiality Checklist (currently lines 292-334, ~40 lines) → `references/confidentiality-checklist.md`

Each extracted section is replaced in SKILL.md with a short pointer (typically 2-4 lines) referencing the new file.

**Success criteria.**

- SKILL.md ≤ 400 lines
- All three new `references/*.md` files exist with full original content preserved
- No semantic changes; existing skill triggers and behaviour identical
- All references in SKILL.md to the moved content updated to point at the new files
- Existing CI on the skill repository remains green

**Exit conditions.** M1 closes when a clean commit lands on `main` with the moved content, the new references files in place, and a sanity test run against an existing project verifies no regression.

## M2 — Bootstrap removal (cross-skill split)

**Goal.** Remove all bootstrap artifact generation from `project-design`. Convert Phase B Step 3 from "generate 05-07 + bootstrap/" to "generate 05-07 + invoke or instruct `repo-bootstrap`".

**Scope.** Files deleted or substantially trimmed:

- `references/bootstrap-artifacts.md` — moved entirely to `repo-bootstrap`'s repository
- `references/ci-cd-templates.md` — moved entirely to `repo-bootstrap`'s repository
- `references/engineering-handbook-templates.md` — trimmed to retain only design-level guidance; concrete YAML templates move to `repo-bootstrap`
- `SKILL.md` § Phase B Step 3 — rewritten to describe handoff to `repo-bootstrap` rather than file generation
- `SKILL.md` § Bootstrap folder — removed

**Success criteria.**

- No `references/bootstrap-artifacts.md` or `references/ci-cd-templates.md` in this repo
- Phase B Step 3 generates only `05-07` documents
- Phase B includes a new Step 0 that decides whether bootstrap is a prerequisite for the implementing agent or a parallel/later task
- 04-agent-instructions in generated packages includes the bootstrap-coupling decision for the operator's downstream awareness

**Exit conditions.** M2 closes when a generated package from a fresh Phase A → B run contains no bootstrap files and the operator can complete the workflow by invoking `repo-bootstrap` separately if needed.

## M3 — Sibling skill construction (`repo-bootstrap`)

**Goal.** Build the `repo-bootstrap` skill as a separate repository, populated with the content extracted in M2, and publish it via the marketplace.

**Scope.** This milestone is owned by a separate design package (`repo-bootstrap-design/` in the `repo-bootstrap-skill` repository). From `project-design`'s perspective, M3 is satisfied when:

- `Mr-RedHat-fb/repo-bootstrap-skill` exists as canonical
- `alfred-intelligence/repo-bootstrap-skill` exists as fork
- The skill is installable from `alfred-intelligence/claude-marketplace`
- Invocation patterns documented in `project-design`'s 04-agent-instructions actually work end-to-end

**Success criteria.**

- A test project run produces a design package from `project-design`, the operator then invokes `repo-bootstrap`, and the resulting repository contains all expected artifacts
- The two skills can also be used independently without errors

**Exit conditions.** M3 closes when both skills are published, the marketplace entry resolves correctly, and an end-to-end run is recorded as passing in the operator's notes.

## M4 — Plugin packaging and publishing

**Goal.** Package and publish both skills via the marketplace. Decide whether one multi-skill plugin or two separate plugins is the right shape.

**Scope.** Use the existing `skill-to-plugin` skill to convert each skill repository to plugin form and register entries in `marketplace.json`. Decision criterion for multi-skill vs. separate:

- **Multi-skill plugin** if operators are expected to install both together (likely true for design-and-bootstrap workflow)
- **Separate plugins** if many operators will want only one (likely true for the secondary persona who has an existing repo and wants only `repo-bootstrap`)

The recommendation at the start of M4 leans toward separate plugins given persona 3 in 01-whitepaper. Final call is the operator's at M4 start.

**Success criteria.**

- Both skills installable via `/plugin install <name>@alfred`
- CI on both skill repositories green
- CI on the marketplace repository green (sources resolve, manifests valid)
- Operator confirms the install-and-run flow works on a fresh machine

**Exit conditions.** M4 closes when first user (the operator on a fresh checkout) can install either or both skills and run them successfully.

## Out of horizon

These are explicitly *not* in M1-M4:

- Migration of existing in-flight project packages to the refactored skill (no migration; existing packages already work with current skill)
- Backwards compatibility shims (none; the skill is single-operator with no external consumers)
- Localization of skill content to non-English (out of scope per output language policy)
- A test harness that exercises Phase A → C against synthetic operator dialogues (interesting but separate effort)
