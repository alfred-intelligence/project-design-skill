# Whitepaper — `project-design` Skill, Refactored

## Problem

The current `project-design` skill conflates two concerns: generating design documents (00-07) and generating repository bootstrap artifacts (LICENSE, GitHub workflows, branch protection JSON, issue templates, and similar). The conflation has three concrete costs:

1. **SKILL.md is bloated.** At 494 lines it sits at the soft 500-line ceiling, with sections like Open Questions Tracking and Implementation Mode taking up disproportionate space inline rather than living in `references/`.
2. **The mental model is muddled.** Operators must internalize that the skill produces both design specifications *and* committable repo files. Implementing agents must distinguish between the two when reading the package. The boundary is implicit and easy to miss.
3. **Bootstrap artifacts have value standalone.** Many operators have an existing repository that needs LICENSE, CI, branch protection, and issue templates without going through full project design. Today they must invoke `project-design` and ignore the design portion, which is awkward and wasteful.

## Solution

Split the skill into two sibling skills with disjoint responsibilities:

| Skill | Owns |
|-------|------|
| `project-design` (this refactor) | Generates 00-07 design documents only. Phase A → B → C structure preserved. |
| `repo-bootstrap` (separate skill) | Generates committable artifacts: LICENSE, README skeleton, `.gitignore`, `.editorconfig`, `CONTRIBUTING`, `CODE_OF_CONDUCT`, `SECURITY`, `.github/` folder with labels, branch protection, repo settings, Dependabot, PR template, issue templates, and CI/release workflows. |

`project-design` continues to reason about design decisions (license choice, branch strategy, CI policy) and writes those decisions into 05-07 as prose. `repo-bootstrap` consumes those decisions (or asks afresh) and renders them as files. The two skills are loosely coupled; `repo-bootstrap` can be used standalone on any repository that has decisions ready.

## Value proposition

For the **operator**: a clearer mental model. "I'm designing" vs. "I'm bootstrapping" are now two separate operations. SKILL.md is short enough to skim. The skills can be invoked independently when only one is needed.

For the **implementing agent**: the design package is unambiguously the design. No mixing of "things to read" with "files to drop into the repo as-is".

For the **maintainer**: two small skills with focused triggers and references are easier to evolve than one large skill with diffuse responsibilities.

## User personas

**Primary — solo developer with implementing agent.** Plans a project, generates 00-07, creates the repo, optionally runs `repo-bootstrap`, then hands off to Claude Code as implementer. The implementing agent reads the design package and executes against it.

**Secondary — team lead bootstrapping a new project.** Uses both skills to produce a standardized design package and matching repo scaffolding that the team can ratify in review.

**Tertiary — operator with an existing repo.** Skips `project-design` entirely and invokes `repo-bootstrap` alone to retrofit an unstructured repo with industry-standard artifacts.

## Out of scope

This skill does not:

- Generate `LICENSE`, `.github/`, workflow YAML, branch protection JSON, issue templates, or any other committable artifact. These belong to `repo-bootstrap`.
- Create the repository on GitHub. The operator does that between Phase A and Phase B.
- Push commits or open PRs. The implementing agent does that, guided by 04 and the Phase B documents.
- Maintain a runtime state between sessions beyond what is written into `{project}-design/`.

## Relationship to `repo-bootstrap`

`project-design`'s Phase B output (the 05-07 documents) contains decisions like *"trunk-based development with squash merges"*, *"release-please with Conventional Commits"*, *"branch protection on main requires CI green"*. These are inputs that `repo-bootstrap` either reads directly from 05-07 or asks for during its own conversation with the operator.

In Phase B, the operator decides whether bootstrap is a prerequisite for the implementing agent (some projects require CI before the agent can validate its work) or whether it can be deferred. See 04 § Phase B start for the decision branch.

## Assumptions carried into Phase B

These are silent assumptions from Phase A that Phase B will present as recommendations:

| Area | Assumption | Why |
|------|------------|-----|
| Strictness | `solo+contrib` | Operator is primary maintainer but the repo is public from day one, so external PRs may arrive |
| Distribution | Plugin via `alfred-intelligence/claude-marketplace` | Already operational; sibling skill `repo-bootstrap` will use the same channel |
| Implementation mode | `iterative` | This is a refactor where discovery during implementation is expected; spec-first would over-constrain |
| Branch strategy | Trunk-based, squash merge to `main` | Matches existing operator practice across alfred-intelligence repos |
| Release cadence | Release-as-needed via tag + release-please | Low traffic skill; cadence-based releases not justified |
| Maintainer contact | GitHub Issues only; no email exposed | `users.noreply.github.com` form acceptable in package metadata if a contact is required |

## Identity disclosure

The operator has explicitly cleared the following identifiers for use in committed artifacts:

- Repository slug `Mr-RedHat-fb/project-design-skill` (canonical)
- Repository slug `alfred-intelligence/project-design-skill` (fork, synced from canonical)
- Marketplace entry repo `alfred-intelligence/claude-marketplace`

No other personal identifiers (email, full name, alternate GitHub handles, machine names, related projects) are cleared for committed artifacts at this time.

## Success criterion for the refactor

The refactor is complete when:

1. `project-design`'s SKILL.md is under 400 lines.
2. The skill generates exactly seven documents (00-07) and no bootstrap files.
3. `repo-bootstrap` exists as a separate skill in a separate repository and can be invoked independently.
4. Both skills are published to `alfred-intelligence/claude-marketplace` as a multi-skill plugin or two separate plugins (decision deferred to Phase B).
5. An end-to-end run on a new project produces the expected combined output without manual stitching.
